package org.ir.crawling.model;

public class CrawlStat {
    private String url;

    public CrawlStat(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
