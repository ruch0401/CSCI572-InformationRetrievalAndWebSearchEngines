package org.ir.cli;

public class Props {
    public static final String SEED_URL_HTTPS = "https://www.latimes.com/";
    public static final String SEED_URL_HTTP = "http://www.latimes.com/";

}
